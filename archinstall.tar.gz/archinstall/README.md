# archinstall

----------------------------------------

Для запуска скрипта

```bash
pacman -Syy git ; git clone https://github.com/linuxshef/archinstall.git ; ./archinstall
```

--------------------------------------------

На ошибки в процессе выполнения команды по поводу git - не обращаем внимания .
